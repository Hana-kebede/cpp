#include<iostream>

using namespace std;

int main(){
 char character;
 cout << "Next Character Printer" << endl;
 cout << "======================" << endl;
 cout << "Please insert any one character : ";
 cin >> character;
 cout << "The next character is " << ++character <<endl;

}